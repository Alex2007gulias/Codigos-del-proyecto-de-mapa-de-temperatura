import pygame
import time

# Define some colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (255, 0, 255)

colors = [BLACK, RED, GREEN, BLUE, YELLOW, PURPLE]

pygame.init()

screen = pygame.display.set_mode([992, 701])
pygame.display.set_caption('Temperatura Aula')

TemperaturaAula_0 = [33, 66, 65, 0, 59, 60, 62, 64, 70, 76, 80, 81, 80, 83, 90, 79, 61, 53, 50, 49, 53, 48, 45, 39]

def compresio(lista):
    comprimida = []
    for temperatura in lista:
        if 0 <= temperatura < 60:
            comprimida.append(0)
        elif 60 <= temperatura < 70:
            comprimida.append(1)
        elif 70 <= temperatura < 80:
            comprimida.append(2)
        elif 80 <= temperatura < 90:
            comprimida.append(3)
        elif 90 <= temperatura < 100:
            comprimida.append(4)
        else:
            comprimida.append(5)
    return comprimida

comprimida = compresio(TemperaturaAula_0)
index = 0
last_update = time.time()
update_interval = 1  # Cambia el color cada 1 segundo

cordenadas = [(85, 90), (85, 120), (85, 150), (85, 180), (85, 210), (85, 240), (85, 270), (85, 300), (85, 330), (85, 360), (85, 390), (85, 420), (85, 450), (85, 480), (85, 510), (85, 540), (85, 570), (85, 600), (85, 630), (85, 660), (85, 690), (85, 720), (85, 750), (85, 780)]

def Mapa(lista, color):
    for coordenada in lista:
        pygame.draw.circle(screen, color, coordenada, 15)

clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill(WHITE)

    current_time = time.time()
    if current_time - last_update >= update_interval:
        index = (index + 1) % len(comprimida)
        last_update = current_time
    
    color = colors[comprimida[index]]
    Mapa(cordenadas, color)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
