# Import necessary libraries
import pygame
import time
import csv

# Define color constants
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (255, 0, 255)

# List of colors to be used for temperature representation
colors = [BLACK, RED, GREEN, BLUE, YELLOW, PURPLE]

# Initialize Pygame
pygame.init()

# Read temperature data from CSV file
with open("c:/Users/Administrador/Downloads/Projecte_temperatura/Proves_python/Aula 21 - 10-03-25.csv", newline='') as f:
    data = csv.reader(f, delimiter=',')
    TemperaturaAula_0 = [float(row[0]) for row in list(data)[1:]]  # Extract temperature values, skipping header

# Define coordinates for temperature points on the map
Cordenadas = [(85, 90), (235, 90), (330, 90), (460, 90), (550, 90), (640, 90), (800, 90), (170, 220), (210, 260), (325, 365), (355, 395), (445, 480)]

# Function to compress temperature values into color indices
def compresio(lista):
    comprimida = []
    for temperatura in lista:
        if 0 <= temperatura < 60:
            comprimida.append(0)
        elif 60 <= temperatura < 70:
            comprimida.append(1)
        elif 70 <= temperatura < 80:
            comprimida.append(2)
        elif 80 <= temperatura < 90:
            comprimida.append(3)
        elif 90 <= temperatura < 100:
            comprimida.append(4)
        else:
            comprimida.append(5)
    return comprimida

# Function to draw temperature points on the screen
def dibujar_punto(lista, color):
    for coordenada in lista:
        pygame.draw.circle(screen, color, coordenada, 15)

# Set up the Pygame window
screen = pygame.display.set_mode([992, 701])
pygame.display.set_caption('Temperatura Aula')

# Initialize clock for controlling frame rate
clock = pygame.time.Clock()
background_position = [0, 0]
font = pygame.font.Font(None, 36)

# Load background image
background_image = pygame.image.load("C:/Users/Administrador/Downloads/Projecte_temperatura/Proves_python/Planol 1a planta_page-0001.jpg").convert()

# Compress temperature data
comprimida = compresio(TemperaturaAula_0)
index = 0
last_update = time.time()
update_interval = 1  # Change color every 1 second

# Main game loop
done = False
while not done:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

    # Draw background
    screen.blit(background_image, background_position)

    # Display mouse coordinates
    x, y = pygame.mouse.get_pos()
    text_surface = font.render(f"({x}, {y})", True, BLACK)
    text_rect = text_surface.get_rect(center=(x, y))
    screen.blit(text_surface, text_rect)

    # Update color index based on time interval
    current_time = time.time()
    if current_time - last_update >= update_interval:
        # 
        index = (index + 1) % len(comprimida)
        print("index", index)
        print("comp", len(comprimida))
        last_update = current_time

    # Get current color based on compressed temperature data
    color = colors[comprimida[index]]
    
    # Draw temperature points
    dibujar_punto(Cordenadas, color)

    # Update display
    pygame.display.flip()
    clock.tick(60)  # Limit to 60 frames per second

# Quit Pygame
pygame.quit()
