import pygame
 
# Define some colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (255, 0, 255)

colors = [BLACK, RED, GREEN, BLUE, YELLOW, PURPLE]
# Call this function so the Pygame library can initialize itself
pygame.init()
 
TemperaturaAula_0 = [33, 66, 65, 0, 59, 60, 62, 64, 70, 76, 80, 81, 80, 83, 90, 79, 61, 53, 50, 49, 53, 48, 45, 39]

def compresio(lista):
    comprimida = []
    for temperatura in lista:
        if 0 <= temperatura < 60:
            comprimida.append(0)
        elif 60 <= temperatura < 70:
            comprimida.append(1)
        elif 70 <= temperatura < 80:
            comprimida.append(2)
        elif 80 <= temperatura < 90:
            comprimida.append(3)
        elif 90 <= temperatura < 100:
            comprimida.append(4)
        else:
            comprimida.append(5)
    return comprimida

# Create an 800x600 sized screen
screen = pygame.display.set_mode([992, 701])
 
# This sets the name of the window
pygame.display.set_caption('CMSC 150 is cool')
 
clock = pygame.time.Clock()
 
# Before the loop, load the sounds:
#click_sound = pygame.mixer.Sound("laser5.ogg")
 
# Set positions of graphics
background_position = [0, 0]

# Get the current mouse position. This returns the position
# as a list of two numbers.
text_position = pygame.mouse.get_pos()
x = text_position[0]
y = text_position[1]

font = pygame.font.Font(None, 36)  # None usa la fuente por defecto, 36 es el tamaño

# Load and set up graphics.
background_image = pygame.image.load("C:/Users/Administrador/Downloads/Projecte_temperatura/Proves_python/Planol 1a planta_page-0001.jpg").convert()
#player_image = pygame.image.load("playerShip1_orange.png").convert()
#player_image.set_colorkey(BLACK)
 
done = False
 
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

 
    # Copy image to screen:
    screen.blit(background_image, background_position)

    # Get the current mouse position
    x, y = pygame.mouse.get_pos()
    
    # Render the text with the current mouse coordinates
    text_surface = font.render(f"({x}, {y})", True, BLACK)
    text_rect = text_surface.get_rect(center=(x, y))
 
    # Copy image to screen:
    screen.blit(text_surface, text_rect)
    
    comprimida = compresio(TemperaturaAula_0)
    for i, valor in enumerate(comprimida):
        color = colors[valor]
        pygame.draw.circle(screen, color, (85 + i*30, 90), 15)
 
    pygame.display.flip()
 
    clock.tick(60)
 
pygame.quit()